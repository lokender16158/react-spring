

export const getApps = state => state.myApps.data;
export const getIsLoading = state => state.myApps.isLoading;